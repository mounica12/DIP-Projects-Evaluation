rows = 768 ;
cols = 1024;
numf = 2;
Color = 'Color.yuv';
Depth = 'Depth.yuv';
Left  = 'Left.yuv';
Right = 'Right.yuv';

%Stereoscopic view generation
[L R] = cd2lr2(Color,Depth,rows, cols, numf);
figure, imshow(yuv2rgb(L{1}.luma,L{1}.chroma1,L{1}.chroma2));
figure, imshow(yuv2rgb(R{1}.luma,R{1}.chroma1,R{1}.chroma2));

fidl = fopen(Left, 'w');
fidr = fopen(Right, 'w');

for s = 1:numf
    FramesOut.Luma = L{s}.luma;
    FramesOut.Chroma1 = L{s}.chroma1;
    FramesOut.Chroma2 = L{s}.chroma2;
    fwrite(fidl, FramesOut.Luma', 'uint8');
    fwrite(fidl, FramesOut.Chroma1', 'uint8');
    fwrite(fidl, FramesOut.Chroma2', 'uint8');
    
    FramesOut.Luma = R{s}.luma;
    FramesOut.Chroma1 = R{s}.chroma1;
    FramesOut.Chroma2 = R{s}.chroma2;
    fwrite(fidr, FramesOut.Luma', 'uint8');
    fwrite(fidr, FramesOut.Chroma1', 'uint8');
    fwrite(fidr, FramesOut.Chroma2', 'uint8');
end

fclose(fidl);
fclose(fidr);




