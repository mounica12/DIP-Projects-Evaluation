function h = find_shiftMC3(depth,Ny)	

% This function will convert the depth pixel value in the depth map to the
% particular pixel shift. Inputs to the system are depth, which is the
% pixel value of the depth map, and Ny is the screen width in pixels.

%
% 

	nkfar=128;
	nknear=128;
	
    kfar=0;
    knear=0;
	
    h=0;
	N=256; % Number of depth planes
	xb=6; %eye separation 6cm
    
    
	Npix = 720; 
    
	D=0;

	h1=0;
	A=0;
	h2=0;

	D = 300; %Viewing Distance usually 300 cm 

	
    knear = nknear/64;
	kfar = nkfar/16;

   
    
    knear = 0;
    
	A= depth*(knear + kfar)/(N-1);

	h1= -xb*Npix*( A - kfar )/D;

	h2= rem (h1/2,1);

	if (h2>=0.5)
		h = ceil(h1/2);
	else
		h = floor(h1/2);
    end

	if (h<0)
        %It will never come here due to Assumption 1
		h=0-h; 
    end
end
    
